#!/bin/bash
python -u manage.py test
